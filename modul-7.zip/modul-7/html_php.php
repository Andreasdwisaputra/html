
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Belajar PHP</title>
</head>
<body>
  <p>Teks ini hanyalah kode HTML sederhana</p>
  <?php echo "<p>Saya berasal dari PHP</p>"; ?>
  <p>Saya berasal dari HTML</p>
  <?php echo "<p>Saya juga berasal dari PHP</p>"; ?>
</body>
</html>

